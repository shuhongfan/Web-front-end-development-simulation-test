window.onload = function() {
    // 根据标签名a获取元素
    var inputval = _______(4)________('a');
    var imgval = document.getElementById('img');
    // 创建一个图像对象
    var yimg = ____(5)_______;
    var iNow = 0;
    yimg.onload = function() {
        draw(imgval);
    }
    // 获取图片的路径
    yimg.src = ___(6)____;

    function draw(obj) {
        // 创建一个canvas标签
        var c = _____(7)____('canvas');
        // 返回一个用于在画布上绘图的环境
        var cxt = ___(8)_____('2d');

        c.width = obj.width;
        c.height = obj.height;
    //将img替换成canvas
        obj.parentNode.___(9)_____(c, obj);

        // 在画布上绘制图像
        cxt._____(10)_____(obj, 0, 0);
        //绑定点击事件
        inputval[1].____(11)___ = function() {
            if (iNow == 3) {
                iNow = 0;
            } else {
                iNow++;
            }
            toChange();
        };


        inputval[0].____(11)___ = function() {
            if (iNow == 0) {
                iNow = 3;
            } else {
                iNow--;
            }
            toChange();
        };

        function toChange() {
            switch (iNow) {
                case 0:
                    c.width = obj.width;
                    c.height = obj.height;
                    // 旋转的角度
                    ______(12)____;
                    cxt.drawImage(obj, 0, 0);
                    break;
                case 1:
                    c.width = obj.height;
                    c.height = obj.width;
                     // 旋转的角度
                    ______(13)____;
                    cxt.drawImage(obj, 0, -obj.height);
                    break;
                case 2:
                    c.width = obj.width;
                    c.height = obj.height;
                     // 旋转的角度
                    ______(14)____;
                    cxt.drawImage(obj, -obj.width, -obj.height);
                    break;
                case 3:
                    c.width = obj.height;
                    c.height = obj.width;
                     // 旋转的角度
                    ______(15)____;
                    cxt.drawImage(obj, -obj.width, 0);
                    break;

            }
        }
    }
}