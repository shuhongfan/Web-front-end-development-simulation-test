//创建vue实例
var vm = _____(6)______({
    el: '___(7)___',
    ___(8)____: {
        list: [
            { id: 1, type: 1, name: '十元代金卷', image_url: 'image/djj.jpg' },
            { id: 2, type: 2, name: '谢谢参与', image_url: 'image/djj.jpg' },
            { id: 3, type: 1, name: '笔记本电脑', image_url: 'image/djj.jpg' },
            { id: 4, type: 1, name: '20元优惠券', image_url: 'image/djj.jpg' },
            { id: 5, type: 1, name: '500积分', image_url: 'image/djj.jpg' },
            { id: 6, type: 1, name: '100元现金', image_url: 'image/djj.jpg' },
            { id: 7, type: 1, name: '健身卡一张', image_url: 'image/djj.jpg' },
            { id: 8, type: 2, name: '谢谢参与', image_url: 'image/djj.jpg' },
        ],
        circleList: [],
        colorCircleFirst: "#F12416",
        colorCircleSecond: "#FFFFFF",
        colorAwardDefault: "#F5F0FC",
        colorAwardSelect: "#ffe400",
        btntop: 0,//按钮的样式
        time: '',//定时器
        indexSelect: 0,//奖品下标
        lottert: 0,//中奖下标
        prize:0,//是否中奖
        prize_name:'',//奖品名字
        men:false
    },
    //当实例创建完成后开始执行初始化方法
    ___(9)____ {
        ____(10)_____;
    },
    // 事件方法执行
    methods: {
        init: function () {
            var ts = this;
            var list = this.list;
            var left = 9;
            var top = 9;
            // 代金券的位置
            for (var i = 0; i < 8; i++) {
                if (i == 0) {
                    left = 9;
                    top = 9;
                } else if (i < 3 && i != 0) {
                    top = top;
                    left = left + 98 + 4;
                } else if (i >= 3 && i < 5) {
                    left = left;
                    top = top + 79 + 4;
                } else if (i >= 5 && i < 7) {
                    left = left - 98 - 4;
                    top = top;
                } else if (i >= 7 && i < 8) {
                    left = left;
                    top = top - 79 - 4;
                }
                list[i].top = top;
                list[i].left = left;
            }
            this.list = list;
            var cleft = 4;
            var ctop = 4;
            var dian = [];
            // 小圆点的位置
            for (var j = 0; j < 24; j++) {
                if (j == 0) {
                    cleft = 4;
                    ctop = 4;
                } else if (j < 6) {
                    ctop = 2;
                    cleft += 55;
                } else if (j == 6) {
                    ctop = 2;
                    cleft = 330;
                } else if (j < 12) {
                    ctop += 46;
                    cleft = 331.5;
                } else if (j == 12) {
                    ctop = 272.5;
                    cleft = 330;
                } else if (j < 18) {
                    ctop = 275;
                    cleft -= 55;
                } else if (j == 18) {
                    ctop = 273;
                    cleft = 5;
                } else {
                    if (!(j < 24)) return;
                    ctop -= 46, cleft = 2.5;
                }
                dian.push({
                    topCircle: ctop,
                    leftCircle: cleft
                })
            }

            this.circleList = dian;
            // 小圆点不停颜色闪烁
            ____(11)_____(function () {
                if (ts.colorCircleFirst == "#FFFFFF") {
                    ts.colorCircleFirst = "#F12416";
                    ts.colorCircleSecond = "#FFFFFF";
                } else {
                    ts.colorCircleFirst = "#FFFFFF";
                    ts.colorCircleSecond = "#F12416";
                    ts.btntop = 0;
                }
            }, 900)
            // 开始按钮上下闪烁
            this.time = setInterval(function () {
                if (ts.btntop == 0) {
                    ts.btntop = -3;
                } else {
                    ts.btntop = 0;
                }
            }, 900)
        },
        startBtn: function (e) {
            // 清除计时器
            _____(12)_____;
            this.men=true;
            this.btntop = 0;
            this.lottert = 0;
            var ts = this;
            var i = this.indexSelect;
            var list = this.list;
            var time = null;
            var s = 0;

            time = setInterval(function () {
                i++;
                i %= 8;
                s += 30;
                ts.indexSelect = i;
                if (ts.lottert > 0 && i + 1 == ts.lottert) {
                    // 清除计时器
                    _______(13)______;
                    ts.time = setInterval(function () {
                        if (ts.btntop == 0) {
                            ts.btntop = -3;
                        } else {
                            ts.btntop = 0;
                        }
                    }, 900);
                    if (list[i].type == 2) {
                        ts.prize = 2;
                    } else {
                        // 将中奖名称赋值
                        _____(14)_______;
                        ts.prize = 1;
                    }
                    
                }
            }, 200 + s);

            setTimeout(function () {
                ts.lottert = ts.randomNum(1, 8);
            }, 2e3);

        },
        randomNum: function (minNum, maxNum) {
            switch (arguments.length) {
                case 1:
                    return parseInt(Math.random() * minNum + 1, 10);
                    ____(15)_____;
                case 2:
                    return parseInt(Math.random() * (maxNum - minNum + 1) + minNum, 10);
                    ____(15)_____;
                default:
                    return 0;
                    ____(15)_____;
            }
        },
        conTinue:function(){
            this.men=false;
            this.prize=0;
        }
    }
});