<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>发布产品</title>
	<link rel="stylesheet" href="static/css/index.css">
</head>
<body>
	<div class="form">
		<h2>添加产品</h2>
		<form action="addProduct.php" method="post"  enctype = "multipart/form-data">
			<ul>
				<li>
					<label>产品名称：</label>
					<input type="text" name="title">
				</li>
				<li>
					<label>缩略图：</label>
					<input type="file" name="thumb">
				</li>
				<li>
					<label>价格：</label>
					<input type="text" name="pric">
				</li>
				<li>
					<input type="submit" value="提交">
				</li>
			</ul>
		</form>
	</div>
</body>
</html>

