<?php 
//1.连接数据库服务器，并判断
$link = ___(5)_____("localhost","root","123456") or die('数据库连接失败！');
//2.设置字符集
mysqli_set_charset($link, 'utf8');
//3.选择数据库
_____(6)____($link,'img');

// 获取参数
$title=___(7)____['title'];
$thumb=upload(___(8)____['thumb']);
$pric=___(7)____['pric'];

//给数据库中插入数据
$sql="_______(9)________";
echo $sql;
$res=mysqli_query($link, $sql);
if($res){
	echo "添加数据成功";
}else{
	echo "添加数据失败";
}

function upload($file){
	//判断是否上传成功
	if(!empty($_FILES) && $file['error']===0){
	    //判断文件的类型
	    $type=$file['type'];
	    if($type == 'image/gif' || $type == 'image/jpeg' || $type == 'image/png'){
	        //判断文件大小
	        $size= $file['size'];
	        // echo $size;
	        if($size< 8*1024*1024){
	            //获取$_FILES文件  临时文件
	            $tmp_file=$file["tmp_name"];
	            // echo $tmp_file;
	            //获取后缀名
	            $ext=pathinfo($file["name"],PATHINFO_EXTENSION);//后缀名
	            //创建新文件名,由于上传的人数多，只要本地文件名相同就会覆盖，所以需要重命名
	            $fileName="file".rand(1,1000000).".".$ext;
	            //保存路径
	            $path="./files";
	            //格式化路径
	            $path=rtrim($path,'/')."/";

	            //拼接上传目录
	            $new_file=$path.$fileName;
	           
	            //临时文件转换成正式文件
	            ___(10)_____($tmp_file,$new_file);
	            return "http://localhost/imgUpload/files/".$fileName;
	        }else{
	            echo "文件过大，无法上传";
	        }
	    }else{
	        echo "文件类型不正确";
	    }
	}else{
	    echo "文件上传失败";
	}
}