function urlParas(){
	// 获取url地址中？后面的字符串
	var search=_______(1)_______;
   //按&分割成数组
	var arr=_____(2)_______;
	// 用ES6中数组方法完成以下功能
	var res=arr.__(3)_____(function(obj,next,index){
		// 将值存到对象中,汉字需要解码
		obj[____(4)___]=_____(5)____(___(6)_____);
		// 返回对象
		____(7)____;
	},{});
	return res;
}
// 将对象中的数据放到页面中的指定位置
document.getElementById("id").innerText=__(8)_____;
document.getElementById("name").innerText=__(9)____;
document.getElementById("type").innerText=____(10)____;