import Vue from 'vue'
import Router from 'vue-router'
import Pos from '@/components/page/Pos'

Vue.use(Router)
// 在（8）处填写路由类
export default new （8）({
  routes: [
    {
      // 在（9）处填写路径
      （9）: '/',
      name: 'Pos',
      // 在（10）处填写组件
      （10）: Pos
    }
  ]
})
