<template>
  <div id="app">
    <!--在（4）处使用双标签实现左侧导航-->
        （4）
    <!--操作区域-->
    <div class="main">
      <!-- 在（5）处使用双标签实现路由视图 -->
      （5）
    </div>
  </div>
</template>
<script>
// 在（6）处填写导入关键字
（6） leftNav from '@/components/common/leftNav'
// 在（7）处填写导出关键字
（7） default {
  name: 'app',
  components:{
    leftNav
  }
}
</script>
<style>
#app {
  font-family: 'Microsoft YaHei','Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: left;
  color: #2c3e50;
   height:100%;
}
.main{
  float:left;
  width:95%; 
  background-color: #EFF2F7;
  height:100%;
  overflow: auto;
}
</style>
