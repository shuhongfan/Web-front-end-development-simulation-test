// 在（1）处补全代码，导入vue
import (1) from 'vue'
import App from './App'
// 在（2）处补全代码，导入router
import （2） from './router'

import ElementUI from 'element-ui'
import 'element-ui/lib/theme-default/index.css'
Vue.config.productionTip = false;
// 在（3）处补全代码，应用第三方ui库
Vue.use(（3）);

new Vue({
  el: '#app',
  router,
  template: '<App/>',
  components: { App }
})
