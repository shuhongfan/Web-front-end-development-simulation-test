const express=require("express")

const app=express()


app.get("/",function(req,res){
    // res.send("ok")
    let data=[ {
          "goodsId": 1,
          "goodsName": "香辣鸡腿堡",
          "price": 18
        }, {
          "goodsId": 2,
          "goodsName": "田园鸡腿堡",
          "price": 15
        },{
          "goodsId": 3,
          "goodsName": "和风汉堡",
          "price": 15
        }, {
          "goodsId": 4,
          "goodsName": "大包薯条",
          "price": 18
        }, {
          "goodsId": 5,
          "goodsName": "脆皮炸鸡腿",
          "price": 20
        },{
          "goodsId": 6,
          "goodsName": "魔法鸡块",
          "price": 20
        }, {
          "goodsId": 7,
          "goodsName": "可乐大杯",
          "price": 10
        },{
          "goodsId": 8,
          "goodsName": "雪顶咖啡",
          "price": 18
        },{
          "goodsId": 9,
          "goodsName": "儿童欢乐套餐",
          "price": 25
        },{
          "goodsId": 10,
          "goodsName": "快乐全家桶",
          "price": 99
        }]
    res.json(data)
})


app.listen(3000)