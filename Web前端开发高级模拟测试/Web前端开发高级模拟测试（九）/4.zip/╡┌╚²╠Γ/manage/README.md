# AwesomePOS 

> 这是为老婆作的快餐店管理系统，已经答应老婆作好几年了都没给他作，今天开始要为老婆制作这个系统。

## 技术栈
前端 ：vue2 + webpack + vueRouter + element

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report
```

For detailed explanation on how things work, checkout the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).
