var round=document.getElementsByClassName("round")[0];
//获取box下的第一个子元素
var box=round.getElementsByClassName("box")[0].___(1)_____;
var btn=round.getElementsByClassName("btn")[0];
btn.onclick=function(){
    // 随机抽取0-359之间的一个数
    var deg=______(2)_______;
    //定义旋转的圈数
    var num=8;
    // 定义旋转的度数
    var rotateDeg=num*360+deg;
    // 设置box的样式
    // 设置box旋转的度数
    box.style.___(3)______="____(4)______";
    // 设置box旋转的时间
    box.style.___(5)_____="5s";
    // 弹出最后中奖信息
    ____(6)____("___(7)_____",5000)
}
function res(deg){
if(deg>=0&&deg<=51){
//弹出中奖信息
        ___(8)___("免单4999");
    }else if(deg>51&&deg<=102){
        ___(8)___("免单50")
    }else if(deg>102&&deg<=153){
        ___(8)___("免单10")
    }else if(deg>153&&deg<=204){
        ___(8)___("免单5")
    }else if(deg>204&&deg<=255){
        ___(8)___("免分期")
    }else if(deg>255&&deg<=306){
        ___(8)___("提额度")
    }else{
        ___(8)___("未中奖")
    }
    // 旋转完成后设置box的自定义属性rotate的值
    box.____(9)___.rotate=deg;
    // 重新设置下次旋转的起点
    box.style.transform="___(10)_____";
    // 时间清空
    box.style.transition="";
}