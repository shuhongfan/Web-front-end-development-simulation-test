// 在（7）处补全代码，使用对象结构获取对象
import {（7）,foo} from './fun'
// 在（8）处补全代码，引入css
 （8）"./css/index.css"
//在（9）处填写html文件的合适的类名
document.getElementsByClassName("(9)")[0].innerHTML=bar('100000')
