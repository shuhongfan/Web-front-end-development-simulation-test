export function bar(a){
    return a+"+"
}

export function foo(a){
    return a+"以上"
}