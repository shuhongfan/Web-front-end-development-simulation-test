var path = require('path');
module.exports = {
  // 在（1）处补全代码，填写入口关键字
  (1): './src/index.js',
  // 在（2）处补全代码，填写出口文件关键字
  (2): {
    path: path.resolve(__dirname, 'dist/'),
    filename: 'index.js'
  },
  // 在（3）处补全代码，填写模块关键字
  （3）: {
      rules: [
        // 在（4）（5）处填写处理css样式文件的loader
        { test: /\.css$/, use: ['（4）','（5）' ]},
        // 在（6）处填写处理图片文件的loader
        { test: /\.(jpg|png|gif)$/, use: [{loader:'（6）',options:{limit:18192} }]  },
        {
          test: /\.js$/,
          exclude: /(node_modules|bower_components)/,
          use: {
            loader: 'babel-loader',
            options: {
              presets: ['@babel/preset-env']
            }
          }}
      ]
    }
};