<template>
  <div id="app">
    <el-container>
      <el-aside
        :width="nav_width"
        style="background: rgb(0, 21, 41);transition: 0.2s;overflow-x:hidden"
      >
        <div id="nav_title">
          <img src="./assets/logo.png" alt="出差管理系统" style="margin: 14px 14px 14px 10px;width:35px;">
          <span style="position: relative; top: 3px; font-size: 17px;">出差管理系统</span>
        </div>
        <div id="nav">
          <el-menu
            :default-active="url"
            class="el-menu-vertical-demo"
            @open="handleOpen"
            @close="handleClose"
            :collapse="isCollapse"
            background-color="rgb(0, 21, 41)" 
            text-color="#fff"
            router
          >
            <el-menu-item index="/Home">
              <i class="el-icon-menu"></i>
              <span slot="title">主页（HOME）</span>
            </el-menu-item>
            <el-menu-item index="">
              <i class="el-icon-document"></i>
              <span slot="title">我要出差</span>
            </el-menu-item>
            <el-menu-item index="">
              <i class="el-icon-share"></i>
              <span slot="title">我要报销</span>
            </el-menu-item>
            <el-menu-item index="">
              <i class="el-icon-setting"></i>
              <span slot="title">我的审批</span>
            </el-menu-item>
            <el-menu-item index="">
              <i class="el-icon-picture-outline"></i>
              <span slot="title">系统管理</span>
            </el-menu-item>
            <el-menu-item index="">
              <i class="el-icon-upload"></i>
              <span slot="title">我的资料</span>
            </el-menu-item>
          </el-menu>
        </div>
      </el-aside>
      <el-container>
        <el-header style="border-bottom: solid 1px #e6e6e6;line-height:68px;">
          <i
            :class="isCollapse?'el-icon-d-arrow-right':'el-icon-d-arrow-left'"
            style="font-size:20px;cursor: pointer;"
            @click="nav_switch"
          ></i>
        </el-header>
        <el-main >
          <!-- <transition name="fade"> -->
            <router-view/>
          <!-- </transition> -->
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script>
export default {
   : "App",//绑定容器
  data() {
    return {
      isCollapse: false,
      nav_width: "255px",
      url:"/Home",
    };
  },
   :{   //监听路由变化
    $ ( to , from ){ //配置路由 
      console.log( to , from );
      //将要去的路径赋值给当前url
      this.url =  .path
    }
  },
  //定义方法
   () {
   //vue创建周期完成后
   //往路由的数组中添加首页地址
    this.$router. ("/Home");
  },
   : {
    handleOpen(key, keyPath) {
      //导航展开/收起
      console.log(key, keyPath);
    },
    handleClose(key, keyPath) {
      //导航展开/收起
      console.log(key, keyPath);
    },
    nav_switch() {
      //导航左右放大缩小
      this.isCollapse = !this.isCollapse;
      if (this.isCollapse) {
        this.nav_width = "64px";
      } else {
        this.nav_width = "255px";
      }
    }
  }
};
</script>

<style>
#app {
  height: 100vh;
  display: flex;
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: black;
  flex-direction: column;
  justify-content: space-between;
  align-content: space-between;
}
#nav_title {
  width: 255px;
  height: 56px;
  color: rgb(255, 255, 255);
  background: rgb(0, 33, 64);
}
#navSwitch {
  font-size: 12px;
}
.el-menu-vertical-demo:not(.el-menu--collapse) {
  width: 255px;
  min-height: 400px;
}
.el-menu {
  border-right: none;
}
.el-menu-item:hover {
  outline: 0;
  color: white !important;
  background-color: #409eff !important;
}
.el-main {
  padding: 0 !important;
}
.el-table thead tr th{
  color: black;
}
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.5s;
}
.fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
  opacity: 0;
}
.el-step__head.is-process{/*步骤条下一步骤样式修改（字体图标）*/
  color: #C0C4CC !important;
  border-color: #C0C4CC !important;
}
.el-step__title.is-process{/*步骤条下一步骤样式修改（文本）*/
  color: #C0C4CC !important;
}
.el-timeline-item__node{/*时间线左侧圆点*/
  background-color: #409EFF !important;
}
.el-timeline-item__tail {/*时间线左侧线段*/
    border-left: 2px solid #409EFF !important;
}
.IntroduceOne .el-upload-list {
  position: relative;
  margin: 0;
  padding: 0;
  list-style: none;
  top: -41px;
  left: -69%;
  z-index: 10;
  width: 66%;
}
.IntroduceOne .el-input__inner {
  cursor: default !important;
}
.IntroduceOne .el-collapse-item__header {
  display: block !important;
}
.IntroduceOne .el-collapse-item__header i {
  margin-left: 3px;
}
.IntroduceOne .el-form-item__label{
  border-left: 4px solid #409EFF !important;
  text-indent: 8px !important;
  font-size: 17px !important;
  font-weight: 700 !important;
  color:#3d3e41 !important;
}
.IntroduceTwo .el-table thead tr th{
  color: black;
  background: #f0f0f0;
}
.IntroduceThree .el-collapse-item__header {
  display: block !important;
}
.IntroduceFour .el-table thead tr th{
  color: black;
  background: #f0f0f0;
}
.IntroduceFive .el-table thead tr th{
  color: black;
  background: #f0f0f0;
}
.IntroduceFive .el-table table tbody tr{
  background: #fafafa;
}
.IntroduceFive .el-collapse-item__header {
  display: block !important;
}
.graphicVersion .el-checkbox-button:first-child .el-checkbox-button__inner {/*图形版本管理-地图选择多选样式修改*/
  border-radius:4px !important;
}
.graphicVersion .el-checkbox-button__inner{/*图形版本管理-地图选择多选样式修改*/
  border-left: 1px solid #DCDFE6 ;
}
.graphicVersion .el-checkbox-button:last-child .el-checkbox-button__inner{/*图形版本管理-地图选择多选样式修改*/
  border-radius:4px !important;
}
.graphicVersion .el-checkbox-button--small .el-checkbox-button__inner{/*图形版本管理-地图选择多选样式修改*/
  border-radius:4px !important;
}
.graphicVersion .el-form-item__label {/*图形版本管理-表单label*/
  font-size: 17px !important;
  border-left: 4px solid #409EFF !important;
}
.graphicVersion .red span{/*图形版本详情电压等级*/
  color: red ;
}
.graphicVersion .green span{
  color: rgb(63, 182, 63) ;
}
.graphicVersion  .blue span{
  color: rgb(0, 162, 255) ;
}
.graphicVersion  .yellow span{
  color: rgb(233, 205, 49) ;
}
.graphicVersion .el-dialog__body{/*图形版本详情时间树*/
  padding: 10px 50px 0 !important;
}

.IntroduceThree_modelVersion .el-checkbox-button:first-child .el-checkbox-button__inner {/*图形版本管理-地图选择多选样式修改*/
  border-radius:4px !important;
}
.IntroduceThree_modelVersion .el-checkbox-button__inner{/*图形版本管理-地图选择多选样式修改*/
  border-left: 1px solid #DCDFE6 ;
}
.IntroduceThree_modelVersion .el-checkbox-button:last-child .el-checkbox-button__inner{/*图形版本管理-地图选择多选样式修改*/
  border-radius:4px !important;
}
.IntroduceThree_modelVersion .el-checkbox-button--small .el-checkbox-button__inner{/*图形版本管理-地图选择多选样式修改*/
  border-radius:4px !important;
}
.IntroduceThree_modelVersion .el-form-item__label {/*图形版本管理-表单label*/
  font-size: 17px !important;
  border-left: 4px solid #409EFF !important;
}
.IntroduceThree_modelVersion .red span{/*图形版本详情电压等级*/
  color: red ;
}
.IntroduceThree_modelVersion .green span{
  color: rgb(63, 182, 63) ;
}
.IntroduceThree_modelVersion  .blue span{
  color: rgb(0, 162, 255) ;
}
.IntroduceThree_modelVersion  .yellow span{
  color: rgb(233, 205, 49) ;
}
.IntroduceThree_modelVersion .el-dialog__body{/*图形版本详情时间树*/
  padding: 10px 50px 0 !important;
}
.IntroduceFive .el-checkbox-button:first-child .el-checkbox-button__inner {/*拼接校验步骤5-多选样式修改*/
  border-radius:4px !important;
}
.IntroduceFive .el-checkbox-button__inner{/*拼接校验步骤5-地图选择多选样式修改*/
  border-left: 1px solid #DCDFE6 ;
}
.IntroduceFive .el-checkbox-button:last-child .el-checkbox-button__inner{/*拼接校验步骤5-地图选择多选样式修改*/
  border-radius:4px !important;
}
.IntroduceFive .el-checkbox-button--small .el-checkbox-button__inner{/*拼接校验步骤5-地图选择多选样式修改*/
  border-radius:4px !important;
}
.home .el-card__body{
  height: calc(100% - 101px) !important;
}
.home .box-card .el-card__body{
  overflow: auto !important;
}
.home .el-carousel__container{
  height: 100% !important
}
.modelVersion_Simple .el-checkbox-button:first-child .el-checkbox-button__inner {/*模型版本easy版本管理-地图选择多选样式修改*/
  border-radius:4px !important;
}
.modelVersion_Simple .el-checkbox-button__inner{/*模型版本easy版本管理-地图选择多选样式修改*/
  border-left: 1px solid #DCDFE6 ;
}
.modelVersion_Simple .el-checkbox-button:last-child .el-checkbox-button__inner{/*模型版本easy版本管理-地图选择多选样式修改*/
  border-radius:4px !important;
}
.modelVersion_Simple .el-checkbox-button--small .el-checkbox-button__inner{/*模型版本easy版本管理-地图选择多选样式修改*/
  border-radius:4px !important;
}
.modelVersion_Simple .el-radio-button:first-child .el-radio-button__inner {/*模型版本easy版本管理-地图选择多选样式修改*/
  border-radius:4px !important;
}
.modelVersion_Simple .el-radio-button__inner{/*模型版本easy版本管理-地图选择多选样式修改*/
  border-left: 1px solid #DCDFE6 ;
}
.modelVersion_Simple .el-radio-button:last-child .el-radio-button__inner{/*模型版本easy版本管理-地图选择多选样式修改*/
  border-radius:4px !important;
}
.modelVersion_Simple .el-radio-button--small .el-radio-button__inner{/*模型版本easy版本管理-地图选择多选样式修改*/
  border-radius:4px !important;
}
.modelVersion_Simple .el-form-item__label {/*模型版本easy版本管理-表单label*/
  font-size: 17px !important;
  border-left: 4px solid #409EFF !important;
}
.modelVersion  .el-form-item__label{
  font-size: 14px !important;
    border-left: 4px solid #409EFF !important;
    font-weight: 600 !important;
    text-indent: 10px !important;
}
.modelVersion .el-card__body{
  height: calc( 100% - 101px) !important;
  overflow: auto !important;
}
.IntroduceOne .el-radio-button:first-child .el-radio-button__inner {/*图形版本管理-地图选择多选样式修改*/
  border-radius:4px !important;
}
.IntroduceOne .el-radio-button__inner{/*图形版本管理-地图选择多选样式修改*/
  border-left: 1px solid #DCDFE6 ;
}
.IntroduceOne .el-radio-button:last-child .el-radio-button__inner{/*图形版本管理-地图选择多选样式修改*/
  border-radius:4px !important;
}
.IntroduceOne .el-radio-button--small .el-radio-button__inner{/*图形版本管理-地图选择多选样式修改*/
  border-radius:4px !important;
}
.IntroduceOne .el-form-item__label {/*图形版本管理-表单label*/
  font-size: 17px !important;
  border-left: 4px solid #409EFF !important;
}
</style>
