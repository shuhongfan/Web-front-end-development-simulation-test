import Vue from 'vue'
import Router from 'vue-router'
import Model_checking from '@/components/integration/Model_checking'
import wholeNetwork_Model_checking from '@/components/wholeNetwork_integration/Model_checking'
import Home from '@/components/home/home'
import graphicVersion from '@/components/graphicVersion/graphicVersion'
import modelVersion from '@/components/modelVersion/modelVersion'//模型版本管理----完整
import modelVersion_Simple from '@/components/modelVersion/modelVersion_Simple'//模型版本管理----简易

Vue.use(Router)

export default new Router({
  routes: [
    {//首页
       :'/Home',//路径
       :'Home',//名称
       :Home//绑定组件
    }
  ]
})
