<template>
  <h1 style="marign:50px;">HOME.VUE</h1>
</template>
