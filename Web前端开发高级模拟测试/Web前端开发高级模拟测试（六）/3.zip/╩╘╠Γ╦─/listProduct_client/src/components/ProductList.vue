<template>
	<div class="wrapper">
		<!-- 搜索框 -->
		<div class="product-search">
			<input type="text" placeholder="输入商品名称" v-model="searchText">
			<button v-on:click="handleSearch">搜索</button>
		</div>
		<!-- 商品列表 -->
		<div class="product" v-for="item in info">
			<a href="javascript:;" class="product-mian">
				<img v-bind:src="item.img">
				<h4>{{ item.name }}</h4>
				<div class="product-prices">￥ {{ item.price }}</div>
				<div class="product-delete" v-on:click="handleDel(item.id)">删除</div>
				<!-- <div class="product-edit">修改商品</div> -->
			</a>
		</div>
	</div>
</template>

<script>
import axios from 'axios'
export default {
	data() {
		return {	
			info: null, // 存放商品数据
			searchText: '' // 存放用户搜索数据
		}
	},
	created() {
		// 请求列表数据，初始化
		this.getList();
	},
	methods:{
		// 获取全部商品列表数据
		getList() {
			axios.get('/products/list')
			.then(res => {
				if (res.data.state == 200){
					this.info = res.data.data;
				}
			})
			.catch(error => {
				console.log(error)
			})
		},
		// 获取商品搜索数据
		handleSearch() {
			axios.get('/products/product',{
				params: {
					name: this.searchText
				}
			})
			.then(res => {
				if (res.data.state == 200){
					this.info = res.data.data;
				}
			})
			.catch(error => {
				console.log(error)
			})
		},
		// 删除
		handleDel(id){
			axios.delete('/products/product',{
				data: {
					id: id
				}
			})
			.then(res => {
				if (res.data.state == 200){
					this.handleSearch();
				}
			})
			.catch(error => {
				console.log(error)
			})
		}
		
	}
}
</script>

<style scoped>
	.wrapper{
		padding: 20px;
	}
	.product-search{
		margin: 20px;
		display: flex;
	}
	.product-search input{
		flex: 1;
		height: 38px;
		border: 1px solid #CCCCCC;
		border-radius: 5px;
		padding-left: 10px;
		font-size: 16px;
	}
	.product-search button{
		width: 80px;
		height: 38px;
		margin-left: 5px;
		background-color: #0070C9;
		color: #FFFFFF;
		border: 1px solid #0070C9;
		border-radius: 5px;
		cursor: pointer;
	}
	.product{
		width: 20%;
		float: left;
	}
	.product-mian{
		display: block;
		margin: 16px;
		padding: 10px;
		border: 1px solid #DDDEE1;
		text-align: center;
		overflow: hidden;
	}
	.product-mian img{
		width: 100%;
	}
	h4{
		color: #222222;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}
	.product-mian:hover h4{
		color: #0070C9;
	}
	.product-prices{
		color: #DE4037;
		margin-top: 6px;
	}
	.product-delete{
		color: #666666;
		font-size: 14px;
		background-color: #F1F1F1;
		margin-top: 6px;
		padding: 8px;
	}
</style>
