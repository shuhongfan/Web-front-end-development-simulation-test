/**
 * @description 返回数据自定义模块
 * 
 */

exports.jsonWrite = (res, ret, add) => {
	if(typeof ret === "undefined") {
		res.json({
			state: "500",
			msg: "操作失败",
		});
	}else {
		res.json({
			state: "200",
			msg: "操作成功",
			data: ret,
		});
	}
};