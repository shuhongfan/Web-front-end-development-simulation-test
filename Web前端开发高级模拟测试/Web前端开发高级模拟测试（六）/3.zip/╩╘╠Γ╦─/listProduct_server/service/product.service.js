/**
 * 业务逻辑
 * 
 */

const productDao = require('../dao/product.dao.js');
const product = require('../model/product.js');

exports.listProduct = (req, callback_controller) => {
	productDao.listProduct((data) => {
		callback_controller(data);
	})
}

exports.selectProduct = (req, callback_controller) => {
	let model = new product(null, req.query.name, null, null);
	productDao.selectProduct(model, (data) => {
		callback_controller(data);
	})
}

exports.deleteProduct = (req,callback_controller) => {
	let model = new product(req.body["id"], null, null, null);
	productDao.deleteProduct(model, (data) => {
		callback_controller(data);
	})
}