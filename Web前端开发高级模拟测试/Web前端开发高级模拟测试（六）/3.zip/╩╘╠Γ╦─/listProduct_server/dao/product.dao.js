/**
 * @description 数据库操作
 * 
 */

const db = require('../util/db.js');

exports.listProduct = (callback_service) => {
	let sql = 'SELECT * FROM product';
	db.query(sql, [], (data) => {
		callback_service(data);
	})
};

exports.selectProduct = (product,callback_service) => {
	let sql = 'SELECT * FROM product WHERE name LIKE "%:name%"';
	db.query(sql, { name: product.name }, (data) => {
		callback_service(data);
	})
}

exports.deleteProduct = (product, callback_service) => {
	let sql = 'DELETE  FROM product WHERE id = :id';
	db.query(sql, { id: product.id }, (data) => {
		callback_service(data);
	})
}