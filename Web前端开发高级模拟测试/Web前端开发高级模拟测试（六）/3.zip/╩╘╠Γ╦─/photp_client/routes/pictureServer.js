let express = require("express");
let router = express.Router();

router.get("/list", (req, res) => {
	let results = ['public/img/1.jpg', 'public/img/2.jpg', 'public/img/3.jpg', 'public/img/4.jpg'];
	res.json({ // 返回数据
		state: "200", // 状态码
		msg: "操作成功", // 提示消息
		data: results
	});
});

module.exports = router;
