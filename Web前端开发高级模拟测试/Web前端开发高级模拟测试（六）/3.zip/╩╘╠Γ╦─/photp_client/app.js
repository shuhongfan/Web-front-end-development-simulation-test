const express = require("express");
const app = express();
const pictureServer = require("./routes/pictureServer.js");

app.use("/public", express.static("public", {"maxAge": 36000000})); 

app.use("/pictureServers", pictureServer);

app.listen(3000);
console.log("Express success listen at port:3000......");
