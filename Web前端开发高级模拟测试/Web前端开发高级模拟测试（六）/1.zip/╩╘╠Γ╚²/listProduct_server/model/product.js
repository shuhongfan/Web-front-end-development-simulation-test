class product {
	constructor(id, name, price, img){
		this.id = id;
		this.name = name;
		this.price = price;
		this.img = img;
	}
	
	get id(){
		return this._id;
	}
	
	set id(id){
		this._id = id;
	}
	
	get name(){
		return this._name;
	}
	
	set name(name){
		this._name = name;
	}
	
	get price(){
		return this._price;
	}
	
	set price(price){
		this._price = price;
	}
	
	get img(){
		return this._img;
	}
	
	set img(img){
		this._img = img;
	}
};

module.exports = product;