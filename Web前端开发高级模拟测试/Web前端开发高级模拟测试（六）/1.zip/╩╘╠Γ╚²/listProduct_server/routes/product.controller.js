/**
 * @description 路由
 * 
 */

const express = require('express');
const router = express.Router();
const productService = require('../service/product.service.js');
const back = require('../util/response.js');

router.get('/products/list', (req, res) => {
	productService.listProduct(req, (data) => {
		back.jsonWrite(res, data);
	})
});

router.get('/products/product', (req, res) => {
	productService.selectProduct(req, (data) => {
		back.jsonWrite(res, data);
	})
});

router.delete('/products/product', (req, res) => {
	productService.deleteProduct(req, (data) => {
		back.jsonWrite(res, data);
	})
});

module.exports = router;
