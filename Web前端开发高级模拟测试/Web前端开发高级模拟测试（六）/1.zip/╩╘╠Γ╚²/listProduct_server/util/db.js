/**
 * @description 数据库连接池自定义模块
 * 
 */

const mysql = require('mysql');

// 连接配置
const pool = mysql.createPool({
	host: 'localhost',
	port: 3306,
	database: 'product',
	user: 'root',
	password: ''
});

// 连接方法
exports.query = (sql, arr, callback_dao) => {
	pool.getConnection((error, conn) => {
		if (error) {
			throw error;
			return;
		};
		//自定义格式
		conn.config.queryFormat = (query, values) => {
			if (!values) return sql;
			return sql.replace(/\:(\w+)/g, (txt, key) => {
				if (values.hasOwnProperty(key)) {
					return values[key];
				}
				return txt;
			});
		};
		conn.query(sql, arr, (error, results) => {
			conn.release();
			if (error) {
				throw error;
			}
			callback_dao(results);
		});
	});
};