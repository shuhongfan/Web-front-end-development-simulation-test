const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const product = require('./routes/product.controller.js');
const http = require('http');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));

app.use('/', product);

http.createServer(app).listen(3000, function() {
	console.log('listening on : 3000');
});

app.use(function(err, req, res, next) {
	console.error(err.stack)
	res.status(500).send('Something broke!')
})