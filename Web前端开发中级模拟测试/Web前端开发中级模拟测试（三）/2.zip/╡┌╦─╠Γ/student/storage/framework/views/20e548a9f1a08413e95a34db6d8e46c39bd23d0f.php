
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>轻松学会Laravel - <?php echo $__env->yieldContent('title'); ?></title>
    <!-- Bootstrap CSS 文件 -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <?php $__env->startSection('style'); ?>

    <?php echo $__env->yieldSection(); ?>
</head>
<body>

<!-- 头部 -->
<?php $__env->startSection('header'); ?>
    <div class="jumbotron">
        <div class="container">
            <h2>学生管理系统</h2>

            <p> </p>
        </div>
    </div>
<?php echo $__env->yieldSection(); ?>

<!-- 中间内容区局 -->
<div class="container">
    <div class="row">

        <!-- 左侧菜单区域   -->
        <div class="col-md-3">
            <?php $__env->startSection('leftmenu'); ?>
                <div class="list-group">
                    <a href="#" class="list-group-item ">学生列表</a>
                    <a href="#" class="list-group-item">新增学生</a>
                </div>
            <?php echo $__env->yieldSection(); ?>
        </div>

        <!-- 右侧内容区域 -->
        <div class="col-md-9">

            <?php echo $__env->yieldContent('content'); ?>

        </div>
    </div>
</div>

<!-- 尾部 -->
<?php $__env->startSection('footer'); ?>
    <div class="jumbotron" style="margin-top:40px">
        <div class="container">
            <span>  @2016  imooc</span>
        </div>
    </div>
<?php echo $__env->yieldSection(); ?>

<!-- jQuery 文件 -->
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<!-- Bootstrap JavaScript 文件 -->
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

<?php $__env->startSection('javascript'); ?>

<?php echo $__env->yieldSection(); ?>

</body>
</html>
