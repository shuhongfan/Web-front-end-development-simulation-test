<?php /* C:\xampp\htdocs\feiyu\resources\views/index.blade.php */ ?>
<!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<title>练习用的主页</title>
		<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no" />
		<link rel="stylesheet" type="text/css" href="dist/css/bootstrap.min.css" />
		<link rel="stylesheet" type="text/css" href="css/common.css" />
		<link rel="stylesheet" href="css/index.css" />
	</head>

	<body>
		<?php echo $__env->make('public/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!--轮播器开始-->
		<div id="myCarousel" class="carousel slide" style="margin-bottom:20px;">
			<ol class="carousel-indicators">
				<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
				<li data-target="#myCarousel" data-slide-to="1"></li>
				<li data-target="#myCarousel" data-slide-to="2"></li>
			</ol>
			<div class="carousel-inner">
				<div class="item active" style="background:#223240">
					<img src="img/Slides-1.jpg" alt="第一张">
				</div>
				<div class="item" style="background:#F5E4DC;">
					<img src="img/Slides-4.jpg" alt="第二张">
				</div>
				<div class="item" style="background:#DE2A2D;">
					<img src="img/Slides-6.jpg" alt="第三张">
				</div>
			</div>
			<a href="#myCarousel" data-slide="prev" class="carousel-control left">
				<span class="glyphicon glyphicon-chevron-left"></span>
			</a>
			<a href="#myCarousel" data-slide="next" class="carousel-control right">
				<span class="glyphicon glyphicon-chevron-right"></span>
			</a>
		</div>
		<!--轮播器结束-->
		<!--办学优势-->
		<div id="youshi" style="margin-bottom:20px;">
			<div class="container">
				<div class="row">
					<div class="col-sm-6 col-md-3">
						<div>
							<a href="###"><img src="img/introduceContainer1.gif"></a>
						</div>
						<div><span>丰富全面的计算机实验课程</span></div>
					</div>
					<div class=" col-sm-6 col-md-3">
						<div>
							<a href="###"><img src="img/introduceContainer1.gif"></a>
						</div>
						<div><span>在线编程环境，1秒启动</span></div>
					</div>
					<div class=" col-sm-6 col-md-3">
						<div>
							<a href="###"><img src="img/introduceContainer3.gif"></a>
						</div>
						<div><span>每天一个项目课，丰富你的项目经验</span></div>
					</div>
					<div class=" col-sm-6 col-md-3">
						<div>
							<a href="###"><img src="img/introduceContainer4.gif"></a>
						</div>
						<div><span>有效学习时间，真实记录你的代码生涯</span></div>
					</div>
				</div>
			</div>
		</div>
		<!--办学优势结束-->
		<!--课程列表-->
		<div id="kecheng" class="container">
			<div class="text-center item-header" style="margin-bottom:20px;">
				<span></span>
				<span class="text-center ">学习路径</span>
				<span></span>
			</div>

			<div class="row">
				<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
					<a href="###">
						<div class="col-xs-5 col-sm-4">
							<img src="img/1471513730333.png">
						</div>
						<div class="col-xs-7 col-sm-8" style="padding-top:20px;">
							<div class="text-center text-muted">C++ 研发工程师</div>
							<div class="text-center text-muted">
								22 门课程
							</div>
						</div>
					</a>
				</div>

				<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
					<a href="###">
						<div class="col-xs-5 col-sm-4">
							<img src="img/1471513769430.png">
						</div>
						<div class="col-xs-7 col-sm-8" style="padding-top:20px;">
							<div class="text-center text-muted">C++ 研发工程师</div>
							<div class="text-center text-muted">
								22 门课程
							</div>
						</div>
					</a>
				</div>

				<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
					<a href="###">
						<div class="col-xs-5 col-sm-4">
							<img src="img/1471513793360.png">
						</div>
						<div class="col-xs-7 col-sm-8" style="padding-top:20px;">
							<div class="text-center text-muted">C++ 研发工程师</div>
							<div class="text-center text-muted">
								22 门课程
							</div>
						</div>
					</a>
				</div>

				<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
					<a href="###">
						<div class="col-xs-5 col-sm-4">
							<img src="img/1471513817808.png">
						</div>
						<div class="col-xs-7 col-sm-8">
							<div>C++ 研发工程师</div>
							<div>
								22 门课程
							</div>
						</div>
					</a>
				</div>

				<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
					<a href="###">
						<div class="col-xs-5 col-sm-4">
							<img src="img/1471513867033.png">
						</div>
						<div class="col-xs-7 col-sm-8" style="padding-top:20px;">
							<div class="text-center text-muted">C++ 研发工程师</div>
							<div class="text-center text-muted">
								22 门课程
							</div>
						</div>
					</a>
				</div>

				<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
					<a href="###">
						<div class="col-xs-5 col-sm-4">
							<img src="img/1471513926288.png">
						</div>
						<div class="col-xs-7 col-sm-8" style="padding-top:20px;">
							<div class="text-center text-muted">C++ 研发工程师</div>
							<div class="text-center text-muted">
								22 门课程
							</div>
						</div>
					</a>
				</div>

				<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
					<a href="###">
						<div class="col-xs-5 col-sm-4">
							<img src="img/1471514004752.png">
						</div>
						<div class="col-xs-7 col-sm-8" style="padding-top:20px;">
							<div class="text-center text-muted">C++ 研发工程师</div>
							<div class="text-center text-muted">
								22 门课程
							</div>
						</div>
					</a>
				</div>

				<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
					<a href="###">
						<div class="col-xs-5 col-sm-4">
							<img src="img/1471514058548.png">
						</div>
						<div class="col-xs-7 col-sm-8" style="padding-top:20px;">
							<div class="text-center text-muted">C++ 研发工程师</div>
							<div class="text-center text-muted">
								22 门课程
							</div>
						</div>
					</a>
				</div>

				<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
					<a href="###">
						<div class="col-xs-5 col-sm-4">
							<img src="img/1471514111981.png">
						</div>
						<div class="col-xs-7 col-sm-8" style="padding-top:20px;">
							<div class="text-center text-muted">C++ 研发工程师</div>
							<div class="text-center text-muted">
								22 门课程
							</div>
						</div>
					</a>
				</div>

				<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
					<a href="###">
						<div class="col-xs-5 col-sm-4">
							<img src="img/1471514153000.png">
						</div>
						<div class="col-xs-7 col-sm-8" style="padding-top:20px;">
							<div class="text-center text-muted">C++ 研发工程师</div>
							<div class="text-center text-muted">
								22 门课程
							</div>
						</div>
					</a>
				</div>

				<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
					<a href="###">
						<div class="col-xs-5 col-sm-4">
							<img src="img/1471514111981.png">
						</div>
						<div class="col-xs-7 col-sm-8" style="padding-top:20px;">
							<div class="text-center text-muted">C++ 研发工程师</div>
							<div class="text-center text-muted">
								22 门课程
							</div>
						</div>
					</a>
				</div>

				<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
					<a href="###">
						<div class="col-xs-5 col-sm-4">
							<img src="img/1471513793360.png">
						</div>
						<div class="col-xs-7 col-sm-8" style="padding-top:20px;">
							<div class="text-center text-muted">C++ 研发工程师</div>
							<div class="text-center text-muted">
								22 门课程
							</div>
						</div>
					</a>
				</div>
			</div>
		</div>
		<!--课程列表-->
		
		<!--推荐就业热门-->
		<div id="tuijian" class="container">
			<div class="text-center item-header" style="margin-bottom:20px;">
				<span></span>
				<span class="text-center ">就业热门</span>
				<span></span>
			</div>
			<div class="row">
				<div class="col-lg-3 col-md-3 col-sm-6 ">
					<div class="thumbnail">
						<img src="img/360截图20161213092244776.jpg"/>
					</div>
					<div>
							<h4>就业页面课程1</h4>
					</div>
					<div>
						<p>说明文字说明文字说明文字说明文字说明文字说明文字说明文字</p>
					</div>
				</div><div class="col-lg-3 col-md-3 col-sm-6 ">
					<div class="thumbnail">
						<img src="img/360截图20161213092244776.jpg"/>
					</div>
					<div>
							<h4>就业页面课程1</h4>
					</div>
					<div>
						<p>说明文字说明文字说明文字说明文字说明文字说明文字说明文字</p>
					</div>
				</div><div class="col-lg-3 col-md-3 col-sm-6 ">
					<div class="thumbnail">
						<img src="img/360截图20161213092244776.jpg"/>
					</div>
					<div>
							<h4>就业页面课程1</h4>
					</div>
					<div>
						<p>说明文字说明文字说明文字说明文字说明文字说明文字说明文字</p>
					</div>
				</div><div class="col-lg-3 col-md-3 col-sm-6 ">
					<div class="thumbnail">
						<img src="img/360截图20161213092244776.jpg"/>
					</div>
					<div>
							<h4>就业页面课程1</h4>
					</div>
					<div>
						<p>说明文字说明文字说明文字说明文字说明文字说明文字说明文字</p>
					</div>
				</div>
			</div>
		</div>
		<!--推荐结束-->
		
		<!--脚部上边内容-->
		<div class="tab2">
	<div class="container">
		<div class="row">
			<div class="col-md-6 col-sm-6 tab2-img">
				<img src="img/tab2.png" class="auto img-responsive center-block" alt="">
			</div>
			<div class="text col-md-6 col-sm-6 tab2-text">
				<h3>强大的学习体系</h3>
				<p>经过管理学大师层层把关、让您的企业突飞猛进。</p>
			</div>
		</div>
	</div>
</div>
<!--脚部上边的内容-->

<div class="tab3">
	<div class="container">
		<div class="row">
			<div class="col-md-6 col-sm-6">
				<img src="img/tab3.png" class="auto img-responsive center-block" alt="">
			</div>
			<div class="text col-md-6 col-sm-6">
				<h3>完美的管理方式</h3>
				<p>最新的管理培训方案，让您的企业赶超同行。</p>
			</div>
		</div>
	</div>
</div>
		
		
<footer id="footer">
	<div class="container">
		<p>企业培训 | 合作事宜 | 版权投诉</p>
		<p>京ICP 备12345678. © 2009-2016 IT网在线学校. Powered by Bootstrap.</p>
	</div>
</footer>
		

		<script src="dist/js/jquery.min.js" type="text/javascript" charset="utf-8"></script>
		<script src="dist/js/bootstrap.min.js" type="text/javascript" charset="utf-8"></script>
		<script type="text/javascript">
			$("#yonganli").popover();
		</script>
	</body>

</html>