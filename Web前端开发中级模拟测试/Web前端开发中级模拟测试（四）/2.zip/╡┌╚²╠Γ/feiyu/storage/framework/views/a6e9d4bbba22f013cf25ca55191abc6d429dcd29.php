<?php /* C:\xampp\htdocs\feiyu\resources\views/information.blade.php */ ?>
﻿<!DOCTYPE html>
<html lang="zh-cn">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1, user-scalable=no">
	<title>项目实战</title>
	<link rel="stylesheet" href="dist/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/common.css" />
	<link rel="stylesheet" href="css/style.css">
</head>
<body>
	<?php echo $__env->make('public/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="jumbotron">
	<div class="container">
		<hgroup>
			<h1>资讯</h1>
			<h4>企业内训的最新动态、资源等...</h4>
		</hgroup>
	</div>
</div>

<div id="information">
	<div class="container">
		<div class="row">
			<div class="col-md-8">
				<div class="container-fluid" style="padding:0;">
			

					<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="row info-content">
						<div class="col-md-5 col-sm-5 col-xs-5">
							<img src="img/<?php echo e($obj->image); ?>" class="img-responsive" alt="">
						</div>
						<div class="col-md-7 col-sm-7 col-xs-7">
							<h4><?php echo e($obj->title); ?></h4>
							<p class="hidden-xs">
								<?php echo str_limit( $obj->content ,$limit=100,$end='......' ); ?>

							</p>
							<p>
								<b><?php echo e($obj->author); ?></b> 
								<b><?php echo e(date("Y/m/d",$obj->time)); ?></b>
							</p>
						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



				</div>
				

			<div>
				<span style="position:relative;top:-30px;">总条数
					<?php echo e($data->total()); ?></span>
				<span  style="position:relative;top:-30px;">当前页
					<?php echo e($data->currentPage()); ?></span>
				<span><?php echo e($data->links()); ?></span></div>




			</div>
			<div class="col-md-4 info-right hidden-xs hidden-sm">
				<blockquote>
					<h2>热门资讯</h2>
				</blockquote>
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-5 col-sm-5 col-xs-5" style="margin: 12px 0; padding: 0">
							<img src="img/info2.jpg" class="img-responsive" alt="">
						</div>
						<div class="col-md-7 col-sm-7 col-xs-7" style="padding-right: 0">
							<h4>苹果四寸手机为何要配置强大的A9处理器？</h4>
							<p>admin 15 / 10 / 11</p>
						</div>
					</div>
					<div class="row">
						<div class="col-md-5 col-sm-5 col-xs-5" style="margin: 12px 0; padding: 0">
							<img src="img/info1.jpg" class="img-responsive" alt="">
						</div>
						<div class="col-md-7 col-sm-7 col-xs-7" style="padding-right: 0">
							<h4>广电总局发布TVOS2.0 华为阿里参与研发</h4>
							<p>admin 15 / 10 / 11</p>
						</div>
					</div>
					<div class="row">
						<div class="col-md-5 col-sm-5 col-xs-5" style="margin: 12px 0; padding: 0">
							<img src="img/info3.jpg" class="img-responsive" alt="">
						</div>
						<div class="col-md-7 col-sm-7 col-xs-7" style="padding-right: 0">
							<h4>六家互联网公司发声明 抵制流量劫持等违法行为</h4>
							<p>admin 15 / 10 / 11</p>
						</div>
					</div>
					<div class="row">
						<div class="col-md-5 col-sm-5 col-xs-5" style="margin: 12px 0; padding: 0">
							<img src="img/info2.jpg" class="img-responsive" alt="">
						</div>
						<div class="col-md-7 col-sm-7 col-xs-7" style="padding-right: 0">
							<h4>苹果四寸手机为何要配置强大的A9处理器？</h4>
							<p>admin 15 / 10 / 11</p>
						</div>
					</div>
					<div class="row">
						<div class="col-md-5 col-sm-5 col-xs-5" style="margin: 12px 0; padding: 0">
							<img src="img/info1.jpg" class="img-responsive" alt="">
						</div>
						<div class="col-md-7 col-sm-7 col-xs-7" style="padding-right: 0">
							<h4>广电总局发布TVOS2.0 华为阿里参与研发</h4>
							<p>admin 15 / 10 / 11</p>
						</div>
					</div>
					<div class="row">
						<div class="col-md-5 col-sm-5 col-xs-5" style="margin: 12px 0; padding: 0">
							<img src="img/info3.jpg" class="img-responsive" alt="">
						</div>
						<div class="col-md-7 col-sm-7 col-xs-7" style="padding-right: 0">
							<h4>六家互联网公司发声明 抵制流量劫持等违法行为</h4>
							<p>admin 15 / 10 / 11</p>
						</div>
					</div>
						<li><a href="">上一页</a></li>
					<div class="row">
						<div class="col-md-5 col-sm-5 col-xs-5" style="margin: 12px 0; padding: 0">
							<img src="img/info2.jpg" class="img-responsive" alt="">
						</div>
						<div class="col-md-7 col-sm-7 col-xs-7" style="padding-right: 0">
							<h4>苹果四寸手机为何要配置强大的A9处理器？</h4>
							<p>admin 15 / 10 / 11</p>
						</div>
					</div>
					<div class="row">
						<div class="col-md-5 col-sm-5 col-xs-5" style="margin: 12px 0; padding: 0">
							<img src="img/info1.jpg" class="img-responsive" alt="">
						</div>
						<div class="col-md-7 col-sm-7 col-xs-7" style="padding-right: 0">
							<h4>广电总局发布TVOS2.0 华为阿里参与研发</h4>
							<p>admin 15 / 10 / 11</p>
						</div>
					</div>
					<div class="row">
						<div class="col-md-5 col-sm-5 col-xs-5" style="margin: 12px 0; padding: 0">
							<img src="img/info3.jpg" class="img-responsive" alt="">
						</div>
						<div class="col-md-7 col-sm-7 col-xs-7" style="padding-right: 0">
							<h4>六家互联网公司发声明 抵制流量劫持等违法行为</h4>
							<p>admin 15 / 10 / 11</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<footer id="footer">
	<div class="container">
		<p>企业培训 | 合作事宜 | 版权投诉</p>
		<p>京ICP 备12345678. © 2009-2016 IT网在线学校. Powered by Bootstrap.</p>
	</div>
</footer>


<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script type="text/javascript">

</script>
</body>
</html>