<?php
// 在（12）处补齐代码，没有设置cookie，跳转到登录页面
if(         （12）           ){
    header("location:http://localhost/login/login.html");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>首页</title>
    <link rel="stylesheet" href="">
</head>
<body>
首页
</body>
</html>





