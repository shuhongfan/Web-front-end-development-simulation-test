<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/quiz.css')); ?>">
</head>
<body>
<h1>在线答题</h1>
<div class="box">
	<h2 id="test_status">第<?php echo e($qid); ?>题</h2>
	<div id="test">
		<form method="post" action="<?php echo e(!$last?'/quiz/next/'.$qid:'/quiz/submit'); ?>"> 
			<?php echo csrf_field(); ?>

			<h3><?php echo e($stem); ?></h3>
			<?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<input type="radio" name="choices" value="<?php echo e($key); ?>"><?php echo e($value); ?></input><br>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<br>
			<?php if(!$last): ?>
			<button type="submit">下一题</button>
			<?php else: ?>
			<button type="submit">提交</button>
			<?php endif; ?>
		</form>
	</div>
</div>
</body>
</html><?php /**PATH D:\soft\wamp2019\www\mylara\resources\views/quiz.blade.php ENDPATH**/ ?>