<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/quiz.css')); ?>">
</head>
<body>
<h1>在线答题</h1>
<div class="box">
	<div>
		<h2 id="test_status">答题结束</h2>
		<div id="test">
			共答对<?php echo e($right_num); ?>题，获得<?php echo e($score); ?>分
		</div>
	</div>
	<br>
	<button type="button" onclick="window.location='/';">重做</button>
</div>
</body>
</html><?php /**PATH D:\soft\wamp2019\www\mylara\resources\views/result.blade.php ENDPATH**/ ?>