<?php
namespace App\Http\Controllers;

use Illuminate\Http\（2）;  //use Illuminate\Http\（2）;

class QuizController extends （3）  //class QuizController extends （3）;
{
	//static （4）=array(
    static （4）=array(
			array("10 + 4 = ?","12","14","16","B"),
			array("20 - 9 = ?","7","13","11","C"),
			array("7 * 3 = ?","21","24","25","A"),
			array("8 / 2 = ?","10","2","4","C")
		);
	const PARAM_ANSWERS="answers";
	private function getQuestion($qid){
		$question=self::$questions[$qid];
		$options=array();
		for($i=1;$i<4;$i++){
			$val=chr(ord("A")+$i-1);
			$options[$val]=$val.".".$question[$i];
		}
	
	return array(
		"qid"=>$qid+1,
		"stem"=>$question[0],
		"options"=>$options,
		"last"=>(count(self::$questions)==$qid+1)?true:false
		);
	}

	public function start(Request $request){
		//读取第一道题
		$question=$this->getQuestion(0);
		//清空session
		$request->session()->（5）(self::PARAM_ANSWERS);  //$request->session()->（5）(self::PARAM_ANSWERS);
		//创建用来保存用户答案的属性
		$request->session()->put(self::PARAM_ANSWERS,array());
		//显示quiz模板
		return view("quiz",$question);
	}

	public function （6）(Request $request,$qid){   //public function （6）(Request $request,$qid){
		//获得上一道题用户的答案
		$choice=$request->input("choices");
		//将用户的答案保存到Session中
		$answers=$request->session()->get(self::PARAM_ANSWERS);
		array_push($answers,$choice);
		$request->session()->put(self::PARAM_ANSWERS,$answers);
		//获得下一道题的内容
		$question=$this->getQuestion($qid);
		return view("quiz",$question);

	}

	public function submit(Request $request){
		//从$Session中取出前面的答案，并清空
		$answers=$request->session()->get(self::PARAM_ANSWERS);
		$request->session()->forget(self::PARAM_ANSWERS);

		//获得最后一道题用户的答案，更新答案列表
		$choice=$request->input("choices");
		array_push($answers,$choice);

		//计算正确答案的个数
		$question_count=count(self::$questions);
		$right_num=0;
		for($i=0;$i<$question_count;$i++){
			if($answers[$i]==self::$questions[$i][4]){
				（7）++;   //（7）++;
			}
		}
		$score=100*($right_num/$question_count);
		//返回result模板页面
		return view("result",["score"=>$score,"right_num"=>$right_num]);
	}
}
