<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<link rel="stylesheet" type="text/css" href="{{URL::（8）('css/quiz.css')}}">  <!--第（8）空-->
</head>
<body>
<h1>在线答题</h1>
<div class="box">
	<h2 id="test_status">第{{$qid}}题</h2>
	<div id="test">
		<form method="post" action="{{!$last?'/quiz/next/'.$qid:'/quiz/submit'}}"> 
			{!!csrf_field()!!}
			<h3>{{$stem}}</h3>
			@foreach($options as $key=>$value)
			<input type="radio" name="（9）" value="{{$key}}">{{$value}}</input><br>   <!--第（9）空-->
			@endforeach
			<br>
			@if(!$last)
			<button type="submit">下一题</button>
			@else
			<button type="submit">提交</button>
			@endif
		</form>
	</div>
</div>
</body>
</html>