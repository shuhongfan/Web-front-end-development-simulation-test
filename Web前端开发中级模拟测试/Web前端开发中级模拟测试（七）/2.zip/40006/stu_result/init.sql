USE stu_result;
/*（3） INTO `result` (`id`, `name`, `age`, `result`) VALUES(1, '张三', 21, '89'),(2, '李四', 20, '67'),(3, '王五', 20, '55');*/
（3） INTO `result` (`id`, `name`, `age`, `result`) VALUES(1, '张三', 21, '89'),(2, '李四', 20, '67'),(3, '王五', 20, '55');