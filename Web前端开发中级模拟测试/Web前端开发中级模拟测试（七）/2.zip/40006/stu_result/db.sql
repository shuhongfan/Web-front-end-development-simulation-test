DROP DATABASE IF EXISTS stu_result;
CREATE DATABASE stu_result;
USE stu_result;
CREATE TABLE IF NOT EXISTS `result` (
  `id` int(11) NOT NULL （1）  COMMENT '序号',  /*`id` int(11) NOT NULL （1）  COMMENT '序号',*/
  `name` varchar(64) NOT NULL COMMENT '姓名',
  `age` int(11) NOT NULL COMMENT '年龄',
  `result` varchar(255) NOT NULL COMMENT '成绩',
	（2） (`id`)    /*（2） (`id`) */
) ENGINE=InnoDB  DEFAULT CHARSET=utf8