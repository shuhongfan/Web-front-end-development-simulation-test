	function getAjax(){
		var xmlhttp;
		xmlhttp=new XMLHttpRequest();
		return xmlhttp;
	}