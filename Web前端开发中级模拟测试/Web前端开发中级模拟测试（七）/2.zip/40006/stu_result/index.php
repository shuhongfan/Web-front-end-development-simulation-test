<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<script type="text/javascript" src="index.js"></script>
</head>
<body>
<h1>学生成绩管理系统</h1>
<table>
<?php 
（8）("conn.php");   /*（8）("conn.php");*/
$sql="select * from （9）";   /*$sql="select * from （9）";*/
$result=$conn->query($sql);
if($result->（10）>0){     /*if($result->（10）>0){*/
	while($row=$result->fetch_assoc()){
		?>
		<tr>
			<td><?php echo $row["id"]; ?></td>
			<td><?php echo $row["（11）"]; ?></td>   <!--第（11）空-->
			<td><?php echo $row["age"]; ?></td>
			<td><?php echo $row["result"]; ?></td>
			<td>
				<button onclick="toUpdate(this)">修改</button>
				<button onclick="remove(this)">删除</button>	
			</td>
		</tr>
<?php
	}
}
 ?>
 </table>
 </body>
</html>
<script type="text/javascript">
	function remove(ele){
		let id=ele.parentElement.parentElement.children[0].innerText;
		window.location.href="remove_server.php?id="+id;
	}
	function toUpdate(ele){
		let id=ele.parentElement.parentElement.children[0].innerText;
		window.location.href="update.php?id="+id;
	}
</script>
