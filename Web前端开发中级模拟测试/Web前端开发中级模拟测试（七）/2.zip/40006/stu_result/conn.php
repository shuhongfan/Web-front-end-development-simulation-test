<?php 
$servername="127.0.0.1";
$username="root";
$password="123456";
$dbname="（4）";  /*$dbname="（4）";*/
//创建连接
$conn=new mysqli(（5）,$username,（6）,$dbname);  /*$conn=new mysqli(（5）,$username,（6）,$dbname);*/
@mysqli_set_charset(（7）,"utf8");    /*@mysqli_set_charset(（7）,"utf8");*/
//检测连接
if($conn->connect_error){
	die("连接失败：".$conn->connect_error);
}	
 ?>
