<?php $__env->startSection('content'); ?>
<div class="content">
  <table>
  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td align="center">
          <input type="checkbox" name="box" value="<?php echo e($v->id); ?>" class="box"/>
        </td>
        <td><?php echo e($v->id); ?></td>
        <td><?php echo e($v->title); ?></td>
        <td><?php echo e($v->pric); ?></td>
        <td>删除</td>
    <tr>
                  
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<input type="button" value="批量删除" id="but" οnclick="fun()">
</div>
<?php $__env->stopSection(); ?> 
 
<script>
  alert($);
 function fun() {
       $("#but").click(function(){
           //获取到所有的input
           var  box = $("input[name='box']");
           //去所有的input长度
           length =box.length;
           //alert(length);
           var str ="";
           for(var i=0;i<length;i++){
               //如果数组中的checked 为true  就将他的id进行拼接
               if(box[i].checked==true){
                   str =str+","+box[i].value;
               }
           }
           //将拼接的字符串第一个，号删除
           str= str.substr(1)
           //ajax  将id传入后台
           $.ajax({
               url:"<?php echo e(url('news_ajax')); ?>",
               type:"get",
               data:{str:str},
               success:function (a) {
                //   alert(a)
               }
           })
           location.reload(0);
       })
   }
</script>

<?php echo $__env->make('muban.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>