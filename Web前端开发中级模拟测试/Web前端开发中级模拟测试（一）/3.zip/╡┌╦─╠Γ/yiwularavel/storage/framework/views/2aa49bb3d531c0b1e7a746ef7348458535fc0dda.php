<?php $__env->startSection('content'); ?>
<div class="content">
	<table>
		<tr>
			<th>序号</th>
			<th>产品名称</th>
			<th>产品价格</th>
			<th>操作</th>
		</tr>
		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($value->id); ?></td>
            <td><?php echo e($value->title); ?></td>
            <td><?php echo e($value->pric); ?></td>
            <td>删除</td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('muban.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>