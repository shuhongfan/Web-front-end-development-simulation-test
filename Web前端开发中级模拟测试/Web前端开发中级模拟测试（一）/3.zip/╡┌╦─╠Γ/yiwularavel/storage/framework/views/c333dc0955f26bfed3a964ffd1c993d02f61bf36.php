<!DOCTYPE html>
<html>
<head>
	<title>登录</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/public.css">
	<link rel="stylesheet" type="text/css" href="css/login.css">

</head>
<body>
	<div class="login">
		<h2>后台管理系统</h2>
		<form action="loginRequest" method="post">
			<?php echo e(csrf_field()); ?>

			<ul>
				<li>
					<input type="text" name="username" placeholder="请输入用户名">
				</li>
				<li>
					<input type="password" name="password" placeholder="请输入密码">
				</li>
				
				<li><input type="submit"></li>
			</ul>	
		</form>
	</div>
</body>
</html>