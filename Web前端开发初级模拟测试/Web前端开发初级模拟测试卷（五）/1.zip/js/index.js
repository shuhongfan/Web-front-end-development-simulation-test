$(function(){
	pubuliu();
    //随着窗口的大小变化重新执行函数
	____(1)_____(function() {
		pubuliu();
	});
})
function pubuliu(){
	var li=$(".box ul li"),num=3,arr=[];
    //获取每个li所占据的宽度
	var liW=li.___(2)____;

	//遍历每个li
li.___(3)____(function(index,val){
		var scrW=window.innerWidth
		if(scrW<550){
			num=2;
			li.css("width","48%")
		}else{
			num=3;
			li.css("width","31%")
		}
			
		if(index<num){
			$(val).css({
				top:0,
				left:__(4)____+"px"
			})
			liH=li.outerHeight(true)
			arr[index]=$(this).outerHeight(true)
		}else{
			var minHeight=arr[0],mindex=0;
       //遍历数组
			arr.__(5)_____(function(val,index){
				if(minHeight>val){
					minHeight=val;
					mindex=index;
				}
			})
			$(this).css({
				top:__(6)_____,
				left:__(7)____+"px"
			})
			arr[___(8)___]=minHeight+$(this).outerHeight(true)
		}
	})	
}