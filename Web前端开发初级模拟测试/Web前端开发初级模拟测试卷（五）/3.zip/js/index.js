//通过id获取元素backTop
var backTop = ______(1)_______("backTop");
    //需求：一开始返回顶部不显示 滚动一点之后再显示 点击返回顶部 回到顶部
    
window.onscroll = function () {
//窗体滚动的时候 判断scrollTop如果大于0就显示返回顶部 否则就隐藏
    backTop.__(2)____.display =___(3)___.top > 0 ? "__(4)____" : "__(5)_____";
};
//点击按钮要回去
backTop.onclick = function () {
    //渐渐的滚回去
    var timer = ___(6)____(function () {
        var target = 0;
        //获取页面当前滚动的距离
        var leader = ___(3)___.top;
        var step = (target - leader) / 10;
        step = step > 0 ? Math.ceil(step) : ___(7)___(step);
        leader = leader + step;
    //滚动到leader位置
        window.___(8)____(0, leader);
        if (____(9)_____) {
        //清除计时器
            ____(10)_____;
        }
    }, 15);
};
//封装计算页面当前滚动的距离的函数
function scroll() {
    return {
        top: window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0,
        left: window.pageXOffset || document.documentElement.scrollLeft || document.body.scrollLeft || 0
    };
}