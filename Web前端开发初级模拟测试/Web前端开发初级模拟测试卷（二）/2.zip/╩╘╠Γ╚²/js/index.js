﻿var imgs = ["images/0.jpg","images/1.jpg", "images/2.jpg", "images/3.jpg", "images/4.jpg",
            "images/5.jpg","images/6.jpg"];
var startId;//开始定时器的id
var index;//随机角标
$(function () {
		//(1)jquery定义开始按钮
		var startBtn= ;
		//(2)jquery定义停止按钮
		var stopBtn= ; 
		//(3)jquery定义小相框图片
		var smallImg= ; 
		//(4)jquery定义大相框图片
		var bigImg= ; 
    //处理按钮是否可以使用的效果
    startBtn.prop("disabled",false);
    stopBtn.prop("disabled",true);
    //给开始按钮绑定单击事件
    startBtn.click(function () {
        //(5)定义循环定时器 20毫秒执行一次
        startId= (function () {
            //处理按钮是否可以使用的效果
            startBtn.prop("disabled",true);
            stopBtn.prop("disabled",false);
            //(6)(7)通过Math的方法生成随机角标 0-6，并且取小，如0.01-0.99都取0
            index = Math. (Math. () * 7);
            //(8)设置小相框的src属性
            smallImg.prop("src", );
        },20);
    });
    //给结束按钮绑定单击事件
    stopBtn.click(function () {
        //处理按钮是否可以使用的效果
        startBtn.prop("disabled",false);
        stopBtn.prop("disabled",true);
        //(9)停止定时器
         (startId);
        //(10)(11)给大相框设置src属性
        bigImg.prop("src", ). ();
        //(12)1秒钟的运行时间显示
        bigImg. (1000);
    });
});