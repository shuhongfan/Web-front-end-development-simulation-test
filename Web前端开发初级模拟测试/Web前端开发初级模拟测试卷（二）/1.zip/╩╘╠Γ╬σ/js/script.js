﻿//(1)声明一个7个长度的数组days

days[0]= '星期日';
days[1]= '星期一';
days[2]= '星期二';
days[3]= '星期三';
days[4]= '星期四';
days[5]= '星期五';
//(2)往数组days后面添加一个元素，值为星期六;


var dateDisplay = document.getElementById('date');
var hourHand = document.getElementById('hour-hand');
var minuteHand = document.getElementById('minute-hand');
var secondHand = document.getElementById('second-hand');
var digitalTime = document.getElementById('digital-time');

var clock = function() {	
    //(3)获取当前时间
	  var timeNow = ;	
	  var day = timeNow.getDay();
		var date = timeNow.getDate();
		var month = timeNow.getMonth();
		dateDisplay.innerHTML = days[day];
		//(4)获取当前时间的秒
		var seconds = ;
		var sRot = seconds * 6 - 90;
		//(5)获取当前时间的分钟
		var minutes = ;
		var mRot = (minutes * 6) + (seconds / 10) - 90;
		//(6)获取当前时间的小时
		var hours = ;
		var hRot = (hours % 12 * 30) + (minutes / 2) - 90;
		
		hourHand.style.transform = "rotate("+hRot+"deg)";
		minuteHand.style.transform = "rotate("+mRot+"deg)";
		secondHand.style.transform = "rotate("+sRot+"deg)";
		//(7)给digitalTime的内容赋值
		digitalTime. = format(hours)+":"+format(minutes)+":"+format(seconds);
	
}

function format(num) {
		//(8)三元运算符，如果小于10则在num前面加个0，否则返回num
		return ;
}

(function run() {
		//(9)调用clock方法
		clock();
		//(10)(11)(12)定义定时器1秒后执行调用自己
		 (function(){ ();}, );
})();