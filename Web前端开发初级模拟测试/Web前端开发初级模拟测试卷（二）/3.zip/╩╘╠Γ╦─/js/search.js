﻿function searchKey() {
    //(1)js中获取id为text1的文本框的值
	  var v = ,
	  //(2)根据标签名获取元素
	  p1 = document. ("p");
	  p1[0].innerHTML=p1[0].innerHTML.replace(/<[^>]+>/g,'');
	  if (v) {
	  	  //(3)(4)(5)(6)js中定义正则的方法以及替换第一个变量，并将替换的元素加上黄颜色的背景
		    p1[0].innerHTML=p1[0].innerHTML.replace(new  ('('+v+')','gi'),'<span style=" : ;"> </span>')
	  }
}
//(7)(8)点击调用方法
document.getElementById("button1"). = ;