

// 获取样式表中的样式
function getStyle(elem){
    if(elem.currentStyle){
        return elem.currentStyle;
    }else{
        return window.getComputedStyle(elem,null);
    }
}

// getElementsByClassName的兼容方法
function getbyClass(name,elem){
    if (document.getElementsByClassName) {
        return (elem||document).getElementsByClassName(name);
    }
    var ele = (elem||document).getElementsByTagName("*");
    var newArr = [];
    for (var i = 0; i < ele.length; i++) {
        var className = ele[i].className;
        var classN = className.split(" ");
        for (var j = 0; j < classN.length; j++) {
            if (classN[j]==name) {
               newArr.push(ele[i]);
               break;
            };
        };

    };
    return newArr;
}
