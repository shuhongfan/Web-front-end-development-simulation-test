
var box=document.getElementById("box");
var shop=getbyClass("shop",box);
var product=getbyClass("product",box);
var jian=getbyClass("jian",box);
var add=getbyClass("add",box);
var rmb=getbyClass("rmb",box);
var pic=getbyClass("pic",box);
var inputText=document.getElementsByName("num");

var all=document.getElementsByName("all")[0];
var shopCheck=document.getElementsByName("shop");
var prodCheck=document.getElementsByName("check");
var list=getbyClass("list",box);

// 初始化
init();
function init(){
    for(var i=0;i<product.length;i++){
        if(inputText[i].value==1){
            jian[i].style.visibility="hidden";
        }
        if(inputText[i].value==10){
            add[i].style.visibility="hidden";
        }
        sum(i);
    }
}
// 绑定加
for(var a=0;a<add.length;a++){
    add[a].index=a;
    add[a].onclick=function(){
        var text=inputText[this.index];
        text.value++;
        if(text.value>=10){
            text.value=10;
            this.style.visibility="hidden";
        }
        if(text.value<10){
            jian[this.index].style.visibility="visible";
        }
        sum(this.index);
    }
}
// 绑定减
for(var j=0;j<jian.length;j++){
    jian[j].index=j;
    jian[j].onclick=function(){
        var text=inputText[this.index];
        text.value--;
        if(text.value<=1){
            text.value=1;
            this.style.visibility="hidden";
        }
        if(text.value>1){
            add[this.index].style.visibility="visible";
        }
        sum(this.index);
    }
}
//  小计的值
function sum(index){
    // console.log(index);
    var prodSum=pic[index].innerText*inputText[index].value;
    rmb[index].innerText=prodSum;
    total();
}

// 全选与反选
all.onclick=function(){
    if(all.checked){
        for(var s=0;s<shopCheck.length;s++){
            shopCheck[s].checked=true;
            checked(s);
        }
    }else{
        for(var s=0;s<shopCheck.length;s++){
            shopCheck[s].checked=false;
            checked(s);
        }
    }
    total();
}

function checked(s){
    var shopProd=getbyClass("checkbox",shop[s].parentNode);
    if(shopCheck[s].checked){
        for(var c=0;c<shopProd.length;c++){
            shopProd[c].checked=true;
        }
    }else{
        for(var c=0;c<shopProd.length;c++){
            shopProd[c].checked=false;
        }
    }
}

// 点击店名
for(var s=0;s<shopCheck.length;s++){
    shopCheck[s].index=s;
    shopCheck[s].onclick=function(){
        var count=0;
        checked(this.index);
        shopLenght();
        total();
    }
}
// 点击产品复选框
for(var i=0;i<list.length;i++){
    list[i].index=i;
    var checkbox=getbyClass("checkbox",list[i]);
    for(var c=0;c<checkbox.length;c++){
        checkbox[c].onclick=function(){
            checkLength(this.parentNode.parentNode.parentNode.index);
            total();
        }
    }
}

function checkLength(index){
    var numC=0;
    var checkbox=getbyClass("checkbox",list[index]);
    for(c=0;c<checkbox.length;c++){
        if(checkbox[c].checked){
            numC++;
        }
    }
    console.log(shopCheck[index]);
    if(numC==checkbox.length){
        shopCheck[index].checked=true;
    }else{
        shopCheck[index].checked=false;
    }
    shopLenght();
}

function shopLenght(){
    var numP=0
    for(var s=0;s<shopCheck.length;s++){
        if(shopCheck[s].checked){
            numP++
        }
    }
    if(numP==shopCheck.length){
        all.checked=true;
    }else{
        all.checked=false;
    }
}

// 计算总金额
function total(){
    var sum=0;
    for(var i=0;i<product.length;i++){
        if(prodCheck[i].checked){
            // console.log(rmb[i].innerText);
            sum+=Number(rmb[i].innerText);
        }
    }
    document.getElementById("total").innerText=sum;
}


