$(function(){
    // 添加行 绑定点击事件
    $(".add").___(5)____(function(){
        var newTr=$("<tr></tr>");
        for(i=0;i<$("thead>tr>th").length;i++){
            newTd=$("<td></td>");
            if(i==0){
                newTd.text($("tbody>tr").length+1);
            }
            if(i==$("thead>tr>th").length-1){
                //设置标签内容
                newTd.__(6)____("<button>删除</button>")
            }
        //追加节点
            newTd.__(7)_____(newTr);
        };
        $("tbody").append(newTr);
        changeColor();
    })

    // 隔行换色
    function changeColor(){
        $("tbody tr:odd").css("background","#f5f5f5");
        $("tbody tr:even").css("background","#fff");
    }
    changeColor();

    // 删除行
    $("tbody").____(8)___("click","button",function(){
        $(this).parents("tr").remove();
        changeColor();
        order();
    });
    //重新排序
    function order(){
        $("tbody tr").__(9)____(function(index){
            $(this).children().eq(0).text(__(10)____);
        });
    }
})