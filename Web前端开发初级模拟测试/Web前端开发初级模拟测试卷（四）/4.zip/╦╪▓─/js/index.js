// 获取元素
//（1）根据标签获取元素
var banner=document.getElementById("banner"),
    ul=banner.____(1)______("ul")[0],
    li=ul.____(1)______("li"),
    leftBtn=document.getElementById("left"),
    rightBtn=document.getElementById("right"),
    pageNav=document.getElementById("pageNav"),
    index=0,
    timer=null,
    animate=false;

// 追加小圆点
for(var i=0;i<li.length-2;i++){
//创建元素
    var pageA=____(2)______("a");
if(i==0){
//设置类名
        pageA.___(3)____="cur";
}
//追加节点
    pageNav.____(4)___(pageA);
}
// 给小圆点绑定点击事件
var aBtn=pageNav.____(1)______("a");
for(var j=0;j<aBtn.length;j++){
//记录索引值
    _____(5)_____;
    aBtn[j].onclick=function(){
        if(animate){
            return
        }
//计算偏移量
        var offset=___(6)_______;
    //传参-当前点击对象的索引值
        btnShow(___(7)____);
        imgShow(offset);
        index=this.index;
    }
}
    //  小圆点点亮
function btnShow(num){
    for(var i=0;i<aBtn.length;i++){
        aBtn[i].___(3)____="";
    }
    aBtn[num].___(3)____="cur";
}
    //  切换图
function imgShow(offset){
    animate=true;
    var speed=offset/10;
    var newLeft=parseInt(ul.style.left)+offset;
    var go=function(){
        if(speed<0&&parseInt(ul.style.left)>newLeft || speed>0 && parseInt(ul.style.left)<newLeft){
            ul.style.left=parseInt(ul.style.left)+speed+"%";
            //延时计时器
___(8)____(go,50);
        }else{
            ul.style.left=(index+1)*(-100)+"%";
            animate=false;
        }
    }
    go();
}
// 给左右箭头绑定点击事件
leftBtn.onclick=function(){
    if(animate){
        return
    }
    index--;
    if(index<0){
        index=aBtn.length-1;
    }
    btnShow(index);
    imgShow(100);
}
rightBtn.onclick=function(){
    if(animate){
        return
    }
    index++;
    if(index==aBtn.length){
        index=0;
    }
    btnShow(index);
    imgShow(-100);
}
// 自动轮播
function lunbo(){
    rightBtn.onclick();
}
timer=setInterval(lunbo,3000);
// 鼠标经过Banner区域清除计时器
banner.onmouseover=function(){
    ____(9)_______;
}
// 鼠标离开继续自动轮播
banner.____(10)____=function(){
    console.log(1);
    timer=setInterval(lunbo,3000);
}